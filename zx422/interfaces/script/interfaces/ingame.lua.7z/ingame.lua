local UIManTemplate = UIManTemplate
local DlgApi  = DlgApi
local GameAi = GameAi
local Format = string.format

InGame = UIManTemplate:new({this = "InGame"});

function InGame:Init()
end

function InGame:Release()

end

function InGame:Tick()
	
end

function InGame:ProcessEvent()
	
end
----------------------------------
function InGame:ResizeWindows()
	if Win_TestTowergame then
		Win_TestTowergame:ResizeWindows();
	end
	
	if Win_TGllkGame then
		Win_TGllkGame:ResizeWindows();
	end
	
--	if Win_TGadventure then
--		Win_TGadventure:ResizeWindows();
--	end
end