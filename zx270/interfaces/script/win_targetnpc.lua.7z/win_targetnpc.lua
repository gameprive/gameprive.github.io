--local require = require
--require("Win_Target")

local tpl = Win_Target

local datamember = 
{
}
Win_TargetNPC = tpl:new(datamember)
