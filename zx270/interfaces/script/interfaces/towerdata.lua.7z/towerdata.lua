--为了计算的方便，数据单位如下约定：时间间隔以毫秒ms为单位
--速度以 像素/毫秒为单位
--Mission，关卡任务，总共6关，每一关又有n个等级，
--每个等级出来一个类型的怪物m只，interval表示怪物出来的时间间隔

Mission = 
{
MissionNum = 6,

--Mission1
{ 
    levelNum = 10, 
    levelInterval = 50000,        --改为每一关的持续时间
    --level1 
    { monsterType = 1, monsterNum = 5, interval = 2000 },  
    --level2 
    { monsterType = 1, monsterNum = 6, interval = 3000 },
    --level3
    { monsterType = 1, monsterNum = 5, interval = 1000},
    --level4 = 
    { monsterType = 1, monsterNum = 6, interval = 2000},
    --level5 = 
    { monsterType = 1, monsterNum = 7, interval = 1000},
    --level6 = 
    { monsterType = 1, monsterNum = 6, interval = 2000},
    --level7 = 
    { monsterType = 1, monsterNum = 10, interval = 1000},
    --level8 = 
    { monsterType = 1, monsterNum = 6, interval = 2000},
    --level9 = 
    { monsterType = 1, monsterNum = 12, interval = 1000},
    --level10 = 
    { monsterType = 1, monsterNum = 6, interval = 2000},
},

--Mission2 = 
{ 
    levelNum = 10, 
    levelInterval = 40000,
    { monsterType = 1, monsterNum = 10, interval = 1500 },  
    { monsterType = 1, monsterNum = 8, interval = 1200 },
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 1000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 1000},
    { monsterType = 1, monsterNum = 5, interval = 900},
    { monsterType = 1, monsterNum = 8, interval = 900},
    { monsterType = 1, monsterNum = 9, interval = 800},
    { monsterType = 1, monsterNum = 10, interval = 800},
},

--Mission3 = 
{ 
    levelNum = 10, 
    levelInterval = 50000,
    { monsterType = 1, monsterNum = 10, interval = 2000 }, 
    { monsterType = 1, monsterNum = 5, interval = 3000 },
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
},
--Mission4 = 
{ 
    levelNum = 10, 
    levelInterval = 50000,
    { monsterType = 1, monsterNum = 10, interval = 2000 }, 
    { monsterType = 1, monsterNum = 5, interval = 3000 },
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
},
--Mission5 = 
{ 
    levelNum = 10, 
    levelInterval = 50000,
    { monsterType = 1, monsterNum = 10, interval = 2000 }, 
    { monsterType = 1, monsterNum = 5, interval = 3000 },
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
},
--Mission6 = 
{ 
    levelNum = 10, 
    levelInterval = 50000,
    { monsterType = 1, monsterNum = 10, interval = 2000 }, 
    { monsterType = 1, monsterNum = 5, interval = 3000 },
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
    { monsterType = 1, monsterNum = 5, interval = 1000},
    { monsterType = 1, monsterNum = 6, interval = 2000},
},

}

--Map width 地图的宽度（宽有几个格子）
--Map height 地图的高度 （高有几个格子）
--gridlength 每个格子的长度(以像素为单位)
--offsetX, offsetY 地图相对于对话框的偏差
--下一步还要加上地图的入口和出口
Map  = { width = 30, height = 30, gridlength = 16, offsetX = 0, offsetY = 64, scale = 1, }

--入口和出口
entryAndExit= 
{
    {
        entry={{1,9},{1,10},{1,11},{1,12},},
        exit ={{30,9},{30,10},{30,11},{30,12},},
    },
}


Interval = { gfxInterval= 80, pigInterval = 150, effectInterval=150, testEffectInterval = 400, towerExpInterval = 400,}
--玩家初始的生命值hp，初始的金钱money，初始的分数score
Player = { hp = 20, money = 80, score = 0, }

--怪物的类型monsterNum个类型
--怪物的基本属性：类型、生命值、速度、打死后奖励的金钱、奖励的分数、对A类伤害的免疫系数、对B类伤害的免疫系数、对减速伤害的免疫系数、成功逃跑后玩家减血量

Monster = 
{
monsterNum = 10,
--monster1
{monsterType = 1, hp = 30, speed = 20, width = 24, height = 24, awardMoney = 5, awardScore = 2, defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 1,},
--monster2 = 
{monsterType = 2, hp = 45, speed = 25, width = 16, height = 16, awardMoney = 6, awardScore = 3,  defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 2,},
--monster3 = 
{monsterType = 3, hp = 50, speed = 20, width = 16, height = 16,  awardMoney = 5, awardScore = 2,  defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 1,},
--monster4 = 
{monsterType = 4, hp = 65, speed = 30, width = 16, height = 16, awardMoney = 6, awardScore = 3,  defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 2,},
--monster5 = 
{monsterType = 5, hp = 40, speed = 20, width = 16, height = 16, awardMoney = 5, awardScore = 2,  defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 1,},
--monster6 = 

{monsterType = 6, hp = 45, speed = 20, width = 16, height = 16, awardMoney = 6, awardScore = 3,  defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 2,},
{monsterType = 7, hp = 40, speed = 20, width = 16, height = 16, awardMoney = 5, awardScore = 2,  defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 1,},
{monsterType = 8, hp = 45, speed = 20, width = 16, height = 16, awardMoney = 6, awardScore = 3,  defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 2,},
{monsterType = 9, hp = 40, speed = 20, width = 16, height = 16, awardMoney = 5, awardScore = 2,  defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 1,},
{monsterType = 10, hp = 45, speed = 20, width = 16, height = 16, awardMoney = 6, awardScore = 3,  defenseA = 0.2, defenseB = 0.3, defenseS = 0.2, reduceHp = 2,},

}

--每个类型的武器都有一定的暴击率

--1 普通的单攻，速度一般，射程一般，伤害一般，价钱最便宜
--2 群攻，在攻击范围之内的怪物都会受到伤害
--3 减速+伤害
--4 快攻，子弹速度比较快，速度快，射程一般，伤害一般
--5 慢攻，类似于导弹，速度慢，射程远，伤害大
--武器类型以后还可以再加，比如加上专门对空的，而怪物也加上空中飞行的

--武器的基本属性：等级、购买花费、卖出价格、发射速度speed（发射子弹的间隔时间）、射程、升级花费、升级冷却时间、
--A类伤害值、B类伤害值、（减速伤害值）、暴击率、暴击后的伤害倍数

--武器的等级，每个武器可以有n个等级，升级之后，武器的发射速度或者射程将会改变，A类伤害值和B类伤害值、或者减速伤害值会改变
--可以考虑将武器的属性统一处理，有些属性置为0即可。
--辅助攻击的给游戏逻辑带来了混乱，暂时不做实现
--bulletSpeed子弹速度，不同类型的武器的子弹速度相差很大，升级武器后建议不提高子弹的速度，避免画面过于混乱
--如果武器没有减速效果，可以将减速概率赋值为0
--如果子弹没有爆炸效果，可以将explodeRange赋值为0

Weapon = 
{
weaponNum = 5,
--weapon1 = 
{ 
gradeNum = 5,
--grade1 = { weaponType = 1, grade = 1, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 0.1, damageA = 1, damageB = 2, criticalStrikeRate= 0.1, CsFactor = 3, assitType = 1, assitRange = 40,  },
--grade2 = { weaponType = 1, grade = 2, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 0.1, damageA = 1, damageB = 2, criticalStrikeRate= 0.1, CsFactor = 3, assitType = 1, assitRange = 40,  },
--grade3 = { weaponType = 1, grade = 3, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 0.1, damageA = 1, damageB = 2, criticalStrikeRate= 0.1, CsFactor = 3, assitType = 1, assitRange = 40,  },
--grade4 = { weaponType = 1, grade = 4, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 0.1, damageA = 1, damageB = 2, criticalStrikeRate= 0.1, CsFactor = 3, assitType = 1, assitRange = 40,  },
--grade5 = { weaponType = 1, grade = 5, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 0.1, damageA = 1, damageB = 2, criticalStrikeRate= 0.1, CsFactor = 3, assitType = 1, assitRange = 40,  },
--grade1 = 
{ weaponType = 1, grade = 1, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 10000, damageA = 1, damageB = 2, reduceSpeed = 0.2, durTime = 300, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20, },
--grade2 = 
{ weaponType = 1, grade = 2, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 1, damageB = 2, reduceSpeed = 0.2, durTime = 400, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20,},
--grade3 = 
{ weaponType = 1, grade = 3, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 1, damageB = 2, reduceSpeed = 0.2, durTime = 500, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20,},
--grade4 = 
{ weaponType = 1, grade = 4, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 1, damageB = 2, reduceSpeed = 0.2, durTime = 300, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20, },
--grade5 = 
{ weaponType = 1, grade = 5, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 1, damageB = 2, reduceSpeed = 0.2, durTime = 400, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20, },
},

--weapon2 = 
{ 
gradeNum = 5,
{ weaponType = 2, grade = 1, buyCost = 5, sellPrice = 3, speed = 3000, range = 60, upgradeCost = 10, upgradeTime = 10000, damageA = 2, damageB = 3, reduceSpeed = 0.2, durTime = 200, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20, },
{ weaponType = 2, grade = 2, buyCost = 5, sellPrice = 3, speed = 3000, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 2, damageB = 3, reduceSpeed = 0.2, durTime = 600, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20,},
{ weaponType = 2, grade = 3, buyCost = 5, sellPrice = 3, speed = 3000, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 2, damageB = 3, reduceSpeed = 0.2, durTime = 300, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20,},
{ weaponType = 2, grade = 4, buyCost = 5, sellPrice = 3, speed = 3000, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 2, damageB = 3, reduceSpeed = 0.2, durTime = 100, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20, },
{ weaponType = 2, grade = 5, buyCost = 5, sellPrice = 3, speed = 3000, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 2, damageB = 3, reduceSpeed = 0.2, durTime = 800, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20, },
},

--weapon3 = 
{ 
gradeNum = 5,
{ weaponType = 3, grade = 1, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 1000, damageA = 1, damageB = 1, reduceSpeed = 0.2, durTime = 200, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20, },
{ weaponType = 3, grade = 2, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 2000, damageA = 2, damageB = 2, reduceSpeed = 0.3, durTime = 300, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20,},
{ weaponType = 3, grade = 3, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 3000, damageA = 3, damageB = 3, reduceSpeed = 0.4, durTime = 400, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20,},
{ weaponType = 3, grade = 4, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 4000, damageA = 4, damageB = 4, reduceSpeed = 0.5, durTime = 500, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20, },
{ weaponType = 3, grade = 5, buyCost = 5, sellPrice = 3, speed = 1000, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 5, damageB = 5, reduceSpeed = 0.6, durTime = 600, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.05, explodeRange = 20, },
},

--weapon4 = 
{ 
gradeNum = 5,
{ weaponType = 4, grade = 1, buyCost = 5, sellPrice = 3, speed = 500, range = 60, upgradeCost = 10, upgradeTime = 10000, damageA = 0.5, damageB = 1, reduceSpeed = 0.2, durTime = 200, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.07, explodeRange = 20, },
{ weaponType = 4, grade = 2, buyCost = 5, sellPrice = 3, speed = 500, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 1, damageB = 2, reduceSpeed = 0.2, durTime = 200, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.07, explodeRange = 20,},
{ weaponType = 4, grade = 3, buyCost = 5, sellPrice = 3, speed = 500, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 2, damageB = 4, reduceSpeed = 0.2, durTime = 200, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.07, explodeRange = 20,},
{ weaponType = 4, grade = 4, buyCost = 5, sellPrice = 3, speed = 500, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 4, damageB = 6, reduceSpeed = 0.2, durTime = 200, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.07, explodeRange = 20, },
{ weaponType = 4, grade = 5, buyCost = 5, sellPrice = 3, speed = 500, range = 60, upgradeCost = 10, upgradeTime = 5000, damageA = 6, damageB = 8, reduceSpeed = 0.2, durTime = 200, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.07, explodeRange = 20, },
},	
					
--weapon5 = 
{ 
gradeNum = 5,
{ weaponType = 5, grade = 1, buyCost = 5, sellPrice = 3, speed = 2000, range = 80, upgradeCost = 10, upgradeTime = 1000, damageA = 1, damageB = 2, reduceSpeed = 0, durTime = 100, criticalStrikeRate= 0.1, CsFactor = 3, bulletSpeed = 0.04, explodeRange = 20, },
{ weaponType = 5, grade = 2, buyCost = 5, sellPrice = 3, speed = 2000, range = 85, upgradeCost = 10, upgradeTime = 2000, damageA = 2, damageB = 4, reduceSpeed = 0, durTime = 100, criticalStrikeRate= 0.15, CsFactor = 3, bulletSpeed = 0.04, explodeRange = 20,},
{ weaponType = 5, grade = 3, buyCost = 5, sellPrice = 3, speed = 2000, range = 90, upgradeCost = 10, upgradeTime = 3000, damageA = 4, damageB = 6, reduceSpeed = 0, durTime = 100, criticalStrikeRate= 0.2, CsFactor = 3, bulletSpeed = 0.04, explodeRange = 20,},
{ weaponType = 5, grade = 4, buyCost = 5, sellPrice = 3, speed = 2000, range = 65, upgradeCost = 10, upgradeTime = 4000, damageA = 6, damageB = 8, reduceSpeed = 0, durTime = 100, criticalStrikeRate= 0.25, CsFactor = 3, bulletSpeed = 0.04, explodeRange = 20, },
{ weaponType = 5, grade = 5, buyCost = 5, sellPrice = 3, speed = 2000, range = 100, upgradeCost = 10, upgradeTime = 5000, damageA = 8, damageB = 10, reduceSpeed = 0, durTime = 100, criticalStrikeRate= 0.3, CsFactor = 3, bulletSpeed = 0.04, explodeRange = 20, },
},

}

--子弹与武器类型相对应