local UIManTemplate = UIManTemplate
local DlgApi  = DlgApi
local GameAi = GameAi
local Format = string.format

local teaminfo, selfid

InGame = UIManTemplate:new({this = "InGame"});

function InGame:Init()
end

function InGame:Release()

end

function InGame:Tick()
	
end

function InGame:ProcessEvent()
	
end

function InGame:ResizeWindows()
	if Win_TowerDefense then
		Win_TowerDefense:ResizeWindows()
	end
	
end