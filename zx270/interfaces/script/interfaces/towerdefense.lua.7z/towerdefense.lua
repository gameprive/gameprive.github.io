local DlgTemplate = DlgTemplate
local DlgApi  = DlgApi
local GameAI	= GameAI
local Format = string.format
local Weapon = Weapon
local Mission = Mission
local Monster = Monster
local Player = Player
local Map  = Map
local entryAndExit = entryAndExit
local Interval = Interval

local datamember = 
{
    this = "Win_TowerDefense",
    m_Monsters = {},
    m_Turrets = {},
    m_Bullets = {},
    m_Gfxs = {},
    m_Map2Turrets = {},
    m_Map2MonsterPos = {},
    m_Player = {},
    m_Mission = {},
    m_CurLevel = {},
    m_Map = {},
    m_Prgs = {},
    m_Effects = {},
    m_TestEffects = {},
    m_PlaceGrid = {},
    m_levelIndex = 1,
    m_curLevelMonsterNum = 0,   -- current level monster number
    m_curMonsterNum = 0,   -- current monster number 
    m_Timer = 0,
    m_levelTimer = 0,
    m_bStart = false,
    m_bChoseTurretBuy = false,
    m_bChoseTurretSell = false,
    m_bSendNextLevelMonster = true,
    m_bEnableSendNextWave = false,
    m_bLButtonDown = false,
    m_bPause = false, 
    m_bCanPlace = false,
    m_missionIndex = 1,
    m_turretIndex =0,
    m_monsterIndex =0,
    m_bulletIndex =0,
    m_gfxIndex = 0,
    m_prgIndex = 1,  --upgrade progress index
    m_effectIndex = 1,
    m_testIndex = 1,
    m_ChosedTurret = 0,
    m_ChosedMonster = 0,
}

local pairs, setmetatable, type = pairs, setmetatable, type
local function CopyTable(src)
  local inst = {}
  for  k,  v in pairs(src) do
     if type(v) == "table"
     then
        inst[k] = CopyTable(v)
     else
        inst[k] = v
     end
  end
  local mt = getmetatable(src)
  setmetatable(inst, src)

  return inst
end

Win_TowerDefense= DlgTemplate:new(datamember)

function Win_TowerDefense:Init()
    
	self:RegisterEvent("Sell", self.OnSell);
	self:RegisterEvent("Upgrade", self.OnUpgrade);
    self:RegisterEvent("Start", self.OnStart);
    self:RegisterEvent("CreateTower", self.OnCreate);
    self:RegisterEvent("ChoseMonster", self.OnChoseMonster);
    self:RegisterEvent("sendnextwave", self.OnSendNextWave)
	self:RegisterEvent(WM_LBUTTONDOWN, self.OnLButtonDown);
	self:RegisterEvent(WM_LBUTTONUP, self.OnLButtonUp);
	self:RegisterEvent(WM_RBUTTONDOWN, self.OnRButtonDown);
	self:RegisterEvent(WM_MOUSEMOVE, self.OnMouseMove)
	self.m_Player = CopyTable(Player)
	self.m_Player["maxhp"] = Player.hp
	
	self.m_Mission = CopyTable(Mission[self.m_missionIndex])
	self.m_CurLevel = self.m_Mission[self.m_levelIndex]
	self.m_Map = CopyTable(Map)
	
	
	for i=1, self.m_Map.width do 
	    self.m_Map2Turrets[i] = {}
	    self.m_Map2MonsterPos[i] = {}
	    for j=1, self.m_Map.height do
	        self.m_Map2Turrets[i][j] = false
	        self.m_Map2MonsterPos[i][j] = false
	    end
	end
	
	for i=1, self.m_Map.width do
	    self.m_Map2Turrets[i][1] = true
	    self.m_Map2Turrets[i][self.m_Map.height] = true
	end
	
	for j=1, self.m_Map.height do
	    self.m_Map2Turrets[1][j] = true
	    self.m_Map2Turrets[self.m_Map.width][j] = true
	end
	   
	GameAI.InitTDPath(self.m_Map.width, self.m_Map.height, entryAndExit)
 
end

function Win_TowerDefense:OnTest()
		local ret = DlgApi.GetItemRect(self.this, "Btn_Test");
		local retdlg = DlgApi.GetDialogProp(self.this);
		
		self:SetItemPos( "Btn_Test", ret.x - retdlg.x - 10, ret.y - retdlg.y - 10);
end


function Win_TowerDefense:OnChoseMonster()

	return true
end

function Win_TowerDefense:ShowDialog()
    
	DlgApi.EnableItem(self.this, "Btn_Sell", false)
	DlgApi.EnableItem(self.this, "Btn_Upgrade", false) 
	DlgApi.EnableItem(self.this, "Btn_tower1",true)
	DlgApi.EnableItem(self.this, "Btn_tower2",true)
	DlgApi.EnableItem(self.this, "Btn_tower3",true)
	DlgApi.EnableItem(self.this, "Btn_tower4",true)
	DlgApi.EnableItem(self.this, "Btn_tower5",true)  
	DlgApi.SetProgress(self.this, "progress_hp", 1) 
	DlgApi.ShowItem(self.this, "monster_hp", false)
	DlgApi.ShowItem(self.this, "gfx_test", false)
	DlgApi.ShowItem(self.this, "monster", false)
	DlgApi.ShowItem(self.this, "bullet", false)
	DlgApi.ShowItem(self.this, "monsterttt", false)
	DlgApi.ShowItem(self.this, "Btn_Turret", false)
	DlgApi.EnableItem(self.this, "Btn_SendNextWave", false)
	DlgApi.ShowItem(self.this, "weaponRange", false)
	DlgApi.ShowItem(self.this, "Btn_ActionDrag", false)
	DlgApi.ShowItem(self.this, "effect", false)
	DlgApi.ShowItem(self.this, "hiteffect", false)
	DlgApi.ShowItem(self.this, "bulletM", false)
	DlgApi.SetItemText(self.this, "Btn_Start", "Start")
	self.ResizeWindows(self)
	
	DlgApi.SetItemText( self.this, "lab_money", "money:"..self.m_Player.money)
	DlgApi.SetItemText(self.this, "lab_score", "score:"..self.m_Player.score)
	DlgApi.SetItemText(self.this, "lab_level", "level:"..self.m_levelIndex)
	math.randomseed(os.time())
  	local filename = "Interfaces\\script\\interfaces\\TowerData.lua"
  	dofile(filename)
end

function Win_TowerDefense:HideDialog()
    self.Reset(self)
end

function Win_TowerDefense:OnStart()
		if not self.m_bStart then
			self.m_bStart = true
			self.m_bPause = false
			DlgApi.SetItemText(self.this, "Btn_Start", "Pause")
		else
		  	self.m_bStart = false
		  	self.m_bPause = true
		  	DlgApi.SetItemText(self.this, "Btn_Start", "Resume")
		end
	return true
end

function Win_TowerDefense:OnCreate()
    if self.m_bPause then
        return true
    end
    
	local dlgname, itemname = DlgApi.GetHitItem()
	if 	itemname == "Btn_tower1" or itemname == "Btn_tower2" or 
		itemname == "Btn_tower3" or itemname == "Btn_tower4" or itemname == "Btn_tower5" then
		self.m_bChoseTurretBuy = true
		self.m_bChoseTurretSell = false
		self.m_ChosedTurret = itemname
		local x, y = GameAI.GetCursorPosition()
		local retdlg = DlgApi.GetDialogProp(self.this)
		DlgApi.SetImageFile(self.this, "Btn_ActionDrag", "TowerDefense\\place.tga", 2)
		DlgApi.SelectImageFrame(self.this, "Btn_ActionDrag", 1)
		self:SetItemPos( "Btn_ActionDrag", (x - retdlg.x)/self.m_Map.scale - self.m_Map.gridlength, (y - retdlg.y)/self.m_Map.scale - self.m_Map.gridlength) 
		DlgApi.ShowItem(self.this, "Btn_ActionDrag", true)
	else
	    self.m_bChoseTurretSell = true
	    self.m_bChoseTurretBuy = false
	    self.m_ChosedTurret = itemname
	end
	return true
end

-- sell turret
function Win_TowerDefense:OnSell()
	if self.m_bChoseTurretSell then
		local turret = self.m_Turrets[self.m_ChosedTurret]
	    DlgApi.DeleteControl(self.this, self.m_ChosedTurret)
		self.IncMoney( self, turret.sellPrice)
		GameAI.SetBlockPosition(turret.gx, turret.gy, 0 )
		
		self.m_Map2Turrets[turret.gx][turret.gy] = false
		self.m_Map2Turrets[turret.gx][turret.gy+1] = false
		self.m_Map2Turrets[turret.gx+1][turret.gy] = false
		self.m_Map2Turrets[turret.gx+1][turret.gy+1] = false
		
		self.m_Turrets[self.m_ChosedTurret] = nil
		self.m_bChoseTurretSell = false
		self.m_ChosedTurret = nil
		DlgApi.EnableItem(self.this, "Btn_Upgrade", false)
		DlgApi.EnableItem(self.this, "Btn_Sell", false)
		DlgApi.ShowItem(self.this, "weaponRange", false)
	end
	return true
end

function Win_TowerDefense:OnUpgrade()
	if self.m_bChoseTurretSell then
	    if self.m_bStart then
	    	DlgApi.EnableItem(self.this, "Btn_Upgrade", false)
	    end
	    local turret = self.m_Turrets[self.m_ChosedTurret]
	    
		self.DecMoney(self, turret.upgradeCost)

		--获取武器下一个级别的数据，升级武器，从配置文件中读取数据

		local wt = turret.weaponType
		local wp = Weapon[wt][turret.grade+1]
		
		turret.grade = turret.grade + 1
		if turret.grade == Weapon[wt].gradeNum  or turret.upgradeCost > self.m_Player.money  then
			DlgApi.EnableItem(self.this,"Btn_Upgrade", false)
		end
		turret.sellPrice = wp.sellPrice
		turret.upgradeCost = wp.upgradeCost
		turret.speed = wp.speed
		turret.range = wp.range
		turret.upgradeTime = wp.upgradeTime
		turret.damageA = wp.damageA
		turret.damageB = wp.damageB
		turret.reduceSpeed = wp.reduceSpeed
		turret.durTime = wp.durTime
		turret.criticalStrikeRate = wp.criticalStrikeRate
		--turret.bulletSpeed = wp.bulletSpeed
		turret.CsFactor = wp.CsFactor
		turret.explodeRange = wp.explodeRange	
		
		if self.m_bStart then
    		turret.bUpgrading = true
    		
    		DlgApi.CreateControl(self.this, "prg_upgrade", "prg_upgrade"..self.m_prgIndex)
    		self:SetItemPos( "prg_upgrade"..self.m_prgIndex, turret.ox- self.m_Map.gridlength + self.m_Map.offsetX, turret.oy- self.m_Map.gridlength +self.m_Map.offsetY )
    		DlgApi.SetProgress(self.this, "prg_upgrade"..self.m_prgIndex, 0)
    		self.m_Prgs["prg_upgrade"..self.m_prgIndex] = { weapon = self.m_ChosedTurret, counter  = 0, durTime = turret.upgradeTime,  }	
    		self.m_prgIndex = self.m_prgIndex + 1
		end
	end
 	return true
end

function Win_TowerDefense:OnSendNextWave()
    --什么时候使能sendnextwave？在规定的时间内把怪物完全消灭
    if self.m_curMonsterNum == 0 and self.m_CurLevel.monsterNum == self.m_curLevelMonsterNum then
    	self.m_levelTimer = self.m_Mission.levelInterval
    	DlgApi.EnableItem(self.this, "Btn_SendNextWave", false)
    	self.m_bEnableSendNextWave = false
    end
    return true
end

function Win_TowerDefense:OnRButtonDown()
		self.m_bChoseTurretBuy = false
		self.m_ChosedTurret = nil
		DlgApi.ShowItem(self.this, "Btn_ActionDrag", false)
		return true
end

function Win_TowerDefense:OnMouseMove()
	
	if self.m_bChoseTurretBuy then
		local x,y = GameAI.GetCursorPosition()
		local retdlg = DlgApi.GetDialogProp(self.this)
		--精确定位的问题
		local mapX = (x - retdlg.x)/self.m_Map.scale - self.m_Map.offsetX
		local mapY = (y - retdlg.y)/self.m_Map.scale - self.m_Map.offsetY
		local gx = math.ceil( mapX/self.m_Map.gridlength)
		local gy = math.ceil( mapY/self.m_Map.gridlength)
		local deltax = mapX % self.m_Map.gridlength
		local deltay = mapY % self.m_Map.gridlength
		if deltax  < self.m_Map.gridlength/2 then
		    gx = gx-1
		end
		if deltay < self.m_Map.gridlength/2 then
		    gy = gy-1
		end
		
		if gx <1 or gy <1 or gx >= self.m_Map.width or gy >= self.m_Map.height then
		    DlgApi.ShowItem(self.this, "Btn_ActionDrag", false)
		    return true
		end
		--更新怪物位置
		for i=1, self.m_Map.width do 
	    	for j=1, self.m_Map.height do
	        	self.m_Map2MonsterPos[i][j] = false
	    	end
		end
		
		for k, v in pairs(self.m_Monsters) do 
		   if v then
		       self.m_Map2MonsterPos[v.gx][v.gy] = true
		   end 
		end
		
		if not self.m_Map2Turrets[gx][gy] and not self.m_Map2Turrets[gx][gy+1] 
			and not self.m_Map2Turrets[gx+1][gy] and not self.m_Map2Turrets[gx+1][gy+1] 
		   	and not self.m_Map2MonsterPos[gx][gy] and not self.m_Map2MonsterPos[gx][gy+1] 
		   	and not self.m_Map2MonsterPos[gx+1][gy] and not self.m_Map2MonsterPos[gx+1][gy+1]  then
		   	    
		   	DlgApi.SelectImageFrame(self.this, "Btn_ActionDrag", 1)
		   	self.m_bCanPlace = true
		   	self.m_PlaceGrid["gx"] = gx
		   	self.m_PlaceGrid["gy"] = gy
		else
		    DlgApi.SelectImageFrame(self.this, "Btn_ActionDrag", 0)
		    self.m_bCanPlace = false 
		end 
		self:SetItemPos( "Btn_ActionDrag", (gx-1)*self.m_Map.gridlength + self.m_Map.offsetX, (gy-1)*self.m_Map.gridlength + self.m_Map.offsetY)
		DlgApi.ShowItem(self.this, "Btn_ActionDrag", true)    
	end
	return true
end

function Win_TowerDefense:OnLButtonDown(itemName, wParam, x, y)
	
	if self.m_bPause then
	    return true           --暂停中
	end
		
	if not self.m_bChoseTurretBuy then
	    if string.match(itemName, "turret%d+") then
	        self.m_bChoseTurretSell = true
	        self.m_ChosedTurret  = itemName
	        --根据选择炮塔的类型显示炮塔的射程范围
	        local turret = self.m_Turrets[itemName]
	        
	        self:SetItemPos( "weaponRange", turret.ox - 32 +self.m_Map.offsetX, turret.oy - 32 + self.m_Map.offsetY) 
	        DlgApi.ShowItem(self.this, "weaponRange", true)	
	        
	        DlgApi.EnableItem(self.this, "Btn_Sell", true)
	        if 	turret.grade < Weapon[turret.weaponType].gradeNum and
	        	turret.upgradeCost <= self.m_Player.money  and 
	        	not turret.bUpgrading then
		        DlgApi.EnableItem(self.this, "Btn_Upgrade", true)
	        else
	            DlgApi.EnableItem(self.this, "Btn_Upgrade", false)	
	        end        
	    elseif string.match(itemName, "monster%d+") then
	    elseif string.match(itemName, "Btn_Upgrade")then
	    elseif string.match(itemName, "Btn_Sell") then
	    else
	        DlgApi.EnableItem(self.this, "Btn_Sell", false)
	        DlgApi.EnableItem(self.this, "Btn_Upgrade", false)
	        DlgApi.ShowItem(self.this, "weaponRange", false)
	    end
	    return true
	end
	
	if self.m_bCanPlace then 
		self.m_bCanPlace = false
		self.m_bLButtonDown = true
	else
	    self.m_bLButtonDown = false
	end
	
	return true
end

function Win_TowerDefense:OnLButtonUp()

		return true		
end

function Win_TowerDefense:ActionDrag()
    
	if self.m_bChoseTurretBuy then
		local x,y = GameAI.GetCursorPosition()
		local retdlg = DlgApi.GetDialogProp(self.this)
		--精确定位的问题
		local mapX = (x - retdlg.x)/self.m_Map.scale - self.m_Map.offsetX
		local mapY = (y - retdlg.y)/self.m_Map.scale - self.m_Map.offsetY
		local gx = math.ceil( mapX/self.m_Map.gridlength)
		local gy = math.ceil( mapY/self.m_Map.gridlength)
		local deltax = mapX % self.m_Map.gridlength
		local deltay = mapY % self.m_Map.gridlength
		if deltax  < self.m_Map.gridlength/2 then
		    gx = gx-1
		end
		if deltay < self.m_Map.gridlength/2 then
		    gy = gy-1
		end
		
		if gx <1  or gy <1 or gx > self.m_Map.width or gy > self.m_Map.height then
		    DlgApi.ShowItem(self.this, "Btn_ActionDrag", false)
		else 
		   	self:SetItemPos( "Btn_ActionDrag", (gx-1)*self.m_Map.gridlength + self.m_Map.offsetX, (gy-1)*self.m_Map.gridlength + self.m_Map.offsetY)    
			DlgApi.ShowItem(self.this, "Btn_ActionDrag", true)
		end
	end
end

function Win_TowerDefense:SetItemPos(item, x , y)
    
   DlgApi.SetItemPos(self.this, item, x * self.m_Map.scale, y * self.m_Map.scale)

end

function Win_TowerDefense:IncMoney(money)
    self.m_Player.money = self.m_Player.money + money
    local m = self.m_Player.money
    DlgApi.SetItemText(self.this, "lab_money", "money:"..m)
    if m >= Weapon[1][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower1", true)
    end
    if m >= Weapon[2][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower2", true)
    end
    if m >= Weapon[3][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower3", true)
    end
    if m >= Weapon[4][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower4", true)
    end
    if m >= Weapon[5][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower5", true)
    end
end

function Win_TowerDefense:DecMoney(money)
    self.m_Player.money = self.m_Player.money - money
    local m = self.m_Player.money
    DlgApi.SetItemText(self.this, "lab_money", "money:"..m)        		
    if m < Weapon[1][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower1", false)
    end
    if m < Weapon[2][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower2", false)
    end
    if m < Weapon[3][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower3", false)
    end
    if m < Weapon[4][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower4", false)
    end
    if m < Weapon[5][1].buyCost then
        DlgApi.EnableItem(self.this, "Btn_tower5", false)
    end    
end

function Win_TowerDefense:ResizeWindows()

	self.m_Map.scale = DlgApi.GetWindowScale()
	
   	for k, v in pairs(self.m_Monsters) do
	   if v then

	   		DlgApi.ShowItem(self.this, "monster_hp"..v.id, true)
			
	   end 
	end 
end

function Win_TowerDefense:CreateTurret()

	if not self.m_bLButtonDown then
	    return true
	end
	
	self.m_bLButtonDown = false	

	local gx = self.m_PlaceGrid.gx
	local gy = self.m_PlaceGrid.gy
	local px = (gx-1) * self.m_Map.gridlength
	local py = (gy-1) * self.m_Map.gridlength
		
	for i=1, self.m_Map.width do 
    	for j=1, self.m_Map.height do
        	self.m_Map2MonsterPos[i][j] = false
    	end
	end
	
	local map2monster = {}
	for k, v in pairs(self.m_Monsters) do
		if v then
			self.m_Map2MonsterPos[v.gx][v.gy] = true
			local m = { v.gx, v.gy, v.route}
			table.insert(map2monster, m)	  
	   	end 
	end
	
	local ret = GameAI.SetBlockPosition(gx, gy, 1, map2monster)
	
	if ret then
	       
		if(self.m_bChoseTurretBuy) then		
			self.m_bChoseTurretBuy = false
		end 
		DlgApi.ShowItem(self.this, "Btn_ActionDrag", false)
		LogPrint("Win_TowerDefense:OnLButtonDown()")
		
		--以后要根据所选择的炮塔来进行创建了。self.m_ChosedTower	
		local ret = DlgApi.CreateControl(self.this, "Btn_Turret", "turret"..(self.m_turretIndex+1) )
		self.m_turretIndex = self.m_turretIndex +1;

		self:SetItemPos( "turret"..self.m_turretIndex, px + self.m_Map.offsetX, py + self.m_Map.offsetY)
		
		DlgApi.SetImageFile(self.this, "turret"..self.m_turretIndex, "TowerDefense\\tower2.tga", 16)
		DlgApi.SelectImageFrame(self.this, "turret"..self.m_turretIndex, 0)
		
		DlgApi.ShowItem(self.this, "turret"..self.m_turretIndex, true)
		
		--Update the Map2Towers.
		self.m_Map2Turrets[gx][gy] = true
		self.m_Map2Turrets[gx+1][gy] = true
		self.m_Map2Turrets[gx][gy+1] = true
		self.m_Map2Turrets[gx+1][gy+1] = true
		
		--以后要从配置文件中直接拷贝
		if self.m_ChosedTurret == "Btn_tower1" then
			self.m_Turrets["turret"..self.m_turretIndex] = CopyTable( Weapon[1][1])
		elseif self.m_ChosedTurret == "Btn_tower2" then
		    self.m_Turrets["turret"..self.m_turretIndex]= CopyTable( Weapon[2][1])
		elseif self.m_ChosedTurret == "Btn_tower3" then
			self.m_Turrets["turret"..self.m_turretIndex] = CopyTable( Weapon[3][1])
		elseif self.m_ChosedTurret == "Btn_tower4" then
			self.m_Turrets["turret"..self.m_turretIndex] = CopyTable( Weapon[4][1])
		elseif self.m_ChosedTurret == "Btn_tower5" then
			self.m_Turrets["turret"..self.m_turretIndex] = CopyTable( Weapon[5][1])
		end
		            		
		local tmpTurret = self.m_Turrets["turret"..self.m_turretIndex]
		tmpTurret["ox"] = gx * self.m_Map.gridlength  --中心点的坐标（相对于地图左上角，而不是对话框左上角），方便其他控件的定位
		tmpTurret["oy"] = gy * self.m_Map.gridlength 
		tmpTurret["cool"] = 0
		tmpTurret["gx"] = gx
		tmpTurret["gy"] = gy
		tmpTurret["bUpgrading"] = false
		tmpTurret["dirIdx"] = 0
		tmpTurret["counter"] = 0
		
		self.DecMoney(self,tmpTurret.buyCost)
		
		--只更新去路被阻塞的怪物的路径
		--对入口和出口的设置不知道对这里的更新路径是否有影响？
		local halfgrid = self.m_Map.gridlength/2
		for k,v in pairs(self.m_Monsters) do 
		    
		    if self.m_Map2Turrets[v.gx][v.gy] then
		        
		        v.gx = math.ceil( (v.px + v.width/2)/ self.m_Map.gridlength)
		        v.gy = math.ceil( (v.py + v.height/2)/ self.m_Map.gridlength)
		        
		        v.px = v.gx * self.m_Map.gridlength - halfgrid - v.width/2
 		    	v.py = v.gy * self.m_Map.gridlength - halfgrid - v.height/2
 		    	
 		    	local ret, nextgx, nextgy = GameAI.GetNextPos(v.gx, v.gy, v.route)
 		    	v.oldgx = v.gx
                v.oldgy = v.gy
                v.gx = nextgx
                v.gy = nextgy
                --如果有必要的话，更新怪物的方向，也就是更换控件的图片
                --更换怪物的方向，要记录怪物旧的方向，如果方向不变，不必更换图片
                local dirx = v.gx - v.oldgx
                local diry = v.gy - v.oldgy
                
                if dirx ~= v.dx or diry ~= v.dy then
                    --update monster direction
                    v.dx = dirx
                    v.dy = diry
                    self.UpdateMonsterDirection(self, dirx, diry, k, v)      
                end
		    end
		end    		    
	end	
   
end

function Win_TowerDefense:CreateMonster(dwDeltaTime)
    if not self.m_bSendNextLevelMonster then
        return true 
    end
   
   	if self.m_bEnableSendNextWave then
   	    DlgApi.EnableItem(self.this, "Btn_SendNextWave", false)
   	    self.m_bEnableSendNextWave = false
   	end
   	
	local retdlg = DlgApi.GetDialogProp(self.this)
	self.m_Timer = self.m_Timer + dwDeltaTime
   	
   	if self.m_Timer + dwDeltaTime > self.m_CurLevel.interval then
    	self.m_Timer  = 0
    	if self.m_curLevelMonsterNum < self.m_CurLevel.monsterNum then
    	  	
            local ret = DlgApi.CreateControl(self.this, "monster", "monster"..(self.m_monsterIndex+1))
            DlgApi.CreateControl(self.this, "monster_hp", "monster_hp"..(self.m_monsterIndex+1))
            self.m_monsterIndex= self.m_monsterIndex+1
            DlgApi.SetImageFile(self.this, "monster"..self.m_monsterIndex, "TowerDefense\\monsterPig.tga", 16)
            DlgApi.SelectImageFrame(self.this, "monster"..self.m_monsterIndex, 4)
            --初始的怪物的格子，从入口坐标中选择
            local gx = 1 
            local gy = 11
            --local gy = math.ceil( retdlg.height/( 2 * self.m_Map.gridlength) )
            
            self.m_Monsters["monster"..self.m_monsterIndex] = CopyTable(Monster[self.m_CurLevel.monsterType])
            local tmpMonster = self.m_Monsters["monster"..self.m_monsterIndex]
            
            tmpMonster["id"] = self.m_monsterIndex
            --怪物的左上角的坐标（相对于地图左上角）
            tmpMonster["px"] = gx * self.m_Map.gridlength - self.m_Map.gridlength/2 - tmpMonster["width"]/2
            tmpMonster["py"] = gy * self.m_Map.gridlength - self.m_Map.gridlength/2 - tmpMonster["height"]/2
            tmpMonster["gx"] = gx
            tmpMonster["gy"] = gy
            tmpMonster["oldgx"] = gx
            tmpMonster["oldgy"] = gy
            tmpMonster["dx"] = 1  --随机从出口产生
            tmpMonster["dy"] = 0
            tmpMonster["route"] = 0  --由出口决定
            tmpMonster["maxhp"] = Monster[self.m_CurLevel.monsterType].hp
            --处理冰冻减速
            tmpMonster["bFreeze"] = false
            tmpMonster["freezeTime"] = 0
            tmpMonster["freezeCounter"] = 0
            --产生怪物动画
            tmpMonster["frameIdx"] = 0
            tmpMonster["framesNum"] = 2   --每个方向有两帧图片来表示动画效果
            tmpMonster["dirIdx"] = 2*2    --向右 方向序号*framesNum
            tmpMonster["frameCounter"] =0
            tmpMonster["frameInterval"] = 400
                 
            local m = self.m_Monsters["monster"..self.m_monsterIndex]
            --刚出来的怪物就要获取下一个移动点，因为有可能刚出来就要改变移动方向
            local ret, nextgx, nextgy = GameAI.GetNextPos(m.gx, m.gy, m.route)
            m.oldgx = m.gx
            m.oldgy = m.gy
            m.gx = nextgx
            m.gy = nextgy
            --如果有必要的话，更新怪物的方向，也就是更换控件的图片
            --更换怪物的方向，要记录怪物旧的方向，如果方向不变，不必更换图片
            local dirx = m.gx - m.oldgx
            local diry = m.gy - m.oldgy
            
            if dirx ~= m.dx or diry ~= m.dy then
                --update monster direction
                m.dx = dirx
                m.dy = diry               
                self.UpdateMonsterDirection(self, dirx, diry, "monster"..self.m_monsterIndex, m)
            end
            
            self:SetItemPos( "monster"..self.m_monsterIndex, m.px + self.m_Map.offsetX, m.py+ self.m_Map.offsetY)        
            DlgApi.ShowItem(self.this, "monster"..self.m_monsterIndex, true)
            DlgApi.SetProgress(self.this, "monster_hp"..self.m_monsterIndex, 1)
            self:SetItemPos( "monster_hp"..self.m_monsterIndex, m.px + self.m_Map.offsetX-2, m.py+self.m_Map.offsetY-4)
            DlgApi.ShowItem(self.this, "monster_hp"..self.m_monsterIndex, true)
            self.m_curLevelMonsterNum = self.m_curLevelMonsterNum +1
            self.m_curMonsterNum = self.m_curMonsterNum +1
    	else
			self.m_bSendNextLevelMonster = false
    	end
   	end
end

function Win_TowerDefense:Tick(dwDeltaTime)
 
    if dwDeltaTime > 50  then
 		dwDeltaTime = 50 
    end

	--没有开始前就可以创建炮塔，
	--但是开始之后的暂停中不可以创建炮塔
	--self.ActionDrag(self)
	self.CreateTurret(self)
	
    if not self.m_bStart then
    	return true
    end
    	
	self.m_levelTimer = self.m_levelTimer + dwDeltaTime
	if self.m_levelTimer > self.m_Mission.levelInterval then
	    self.m_levelTimer = 0
	    self.m_levelIndex = self.m_levelIndex + 1
	    if self.m_levelIndex > self.m_Mission.levelNum then
	       -- 通过这一关了。 通关了有没有什么花样和奖励，放在这里处理
	       --DlgApi.PopupMessageBox(4, "Pass Level", "恭喜您通过了这一关，继续挑战下一关？")
	       
	       self.m_missionIndex = self.m_missionIndex + 1
	       
	       if self.m_missionIndex > Mission.MissionNum then
	       	--完全通关了，		    
	          self.m_bStart = false
	          self.m_missionIndex = 1
	          self.m_levelIndex = 1
	          self.Reset(self)
	          return true 
	       end
	       self.m_levelIndex = 1
	       self.m_Mission = CopyTable(Mission[self.m_missionIndex]) 
	       --self.m_CurLevel = self.m_Mission["level"..self.m_levelIndex]
	    end
	    
	    DlgApi.SetItemText(self.this, "lab_level", "level:"..self.m_levelIndex)
	   	self.m_CurLevel = self.m_Mission[self.m_levelIndex]
	    self.m_curLevelMonsterNum = 0
	    self.m_bSendNextLevelMonster = true
	end
	
	self.CreateMonster(self, dwDeltaTime)	
    
    for k, v in pairs(self.m_Turrets) do
    	if v then
    		v.cool = v.cool + dwDeltaTime
    	end
    end
  	
	self.UpdateGfxs(self, dwDeltaTime)
	  	
  	self.UpdateMonsters(self, dwDeltaTime)
  	
	self.UpdateBullets(self, dwDeltaTime)
	
	self.UpdateTowersExp(self, dwDeltaTime)
	
	self.UpdatePrgs(self, dwDeltaTime)
	
	self.UpdateEffects(self, dwDeltaTime)
  	   
end
 
function Win_TowerDefense:UpdateGfxs(dwDeltaTime)
  	
  	--特效播放
  	for k,v in pairs(self.m_Gfxs) do 
  	    if v then
  	        v.st = v.st +dwDeltaTime
  	        if v.st > Interval.gfxInterval then
  	            v.idx = v.idx +1
  	            if v.idx == v.framesNum then
  	            	DlgApi.ShowItem(self.this, k, false)
  	            	DlgApi.DeleteControl(self.this, k)
  	            	self.m_Gfxs[k] = nil
  	            else         	                
      	            DlgApi.SelectImageFrame(self.this, k, v.idx)
      	            v.st = 0
  	            end 
  	        end
  	    end
  	end
  	
end  	

--武器升级进度条
function Win_TowerDefense:UpdatePrgs(dwDeltaTime)
	for k, v in pairs(self.m_Prgs) do
	   if v then
	   		v.counter = v.counter + dwDeltaTime
	   		if v.counter > v.durTime then
	   		    local turret = self.m_Turrets[v.weapon]
				turret.bUpgrading = false
				if self.m_ChosedTurret == v.weapon and turret.grade < Weapon[turret.weaponType].gradeNum then
				    DlgApi.EnableItem(self.this, "Btn_Upgrade", true)
				end
				DlgApi.DeleteControl(self.this, k)
				self.m_Prgs[k] = nil

	   		else
	   		    DlgApi.SetProgress(self.this, k, v.counter/v.durTime)
	   		end	   			
	   end 
	end    
end

function Win_TowerDefense:UpdateMonsterDirection(dirx, diry, k, v)
    
 	if dirx ==1 then
 	    if diry == 1 then 
 	       DlgApi.SelectImageFrame(self.this, k, v.framesNum)
 	       v.frameIdx = 0
 	       v.dirIdx = v.framesNum
 	    elseif diry == 0 then
 	        DlgApi.SelectImageFrame(self.this, k, 2*v.framesNum)
 	       v.frameIdx = 0
 	       v.dirIdx = 2*v.framesNum    	 		    	 
 	    elseif diry == -1 then
 	        DlgApi.SelectImageFrame(self.this, k, 3*v.framesNum)
 	       v.frameIdx = 0
 	       v.dirIdx = 3*v.framesNum
 	    end
 	elseif dirx == 0 then
 	    if diry == 1 then
 	        DlgApi.SelectImageFrame(self.this, k, 0)
 	       v.frameIdx = 0
 	       v.dirIdx = 0
 	    elseif diry == -1 then
 	        DlgApi.SelectImageFrame(self.this, k, 4*v.framesNum)
 	       v.frameIdx = 0
 	       v.dirIdx = 4*v.framesNum
 	    end
 	elseif dirx == -1 then
 	    if diry == 1 then
 	        DlgApi.SelectImageFrame(self.this, k, 7*v.framesNum)
 	       v.frameIdx = 0
 	       v.dirIdx = 7*v.framesNum
 	    elseif diry == 0 then
 	        DlgApi.SelectImageFrame(self.this, k, 6*v.framesNum)
 	       v.frameIdx = 0
 	       v.dirIdx = 6*v.framesNum
 	    elseif diry == -1 then
 	        DlgApi.SelectImageFrame(self.this, k, 5*v.framesNum)
 	       v.frameIdx = 0
 	       v.dirIdx = 5*v.framesNum
 	    end
 	end        
end

function Win_TowerDefense:UpdateTowersExp(dwDeltaTime)
	for k, v in pairs(self.m_Turrets) do 
	    if not v.bUpgrading then
	        v.counter = v.counter +dwDeltaTime
	        if v.counter > Interval.towerExpInterval then
	            v.counter = 0
    	        if v.dirIdx % 2 == 0 then
    	            v.dirIdx = v.dirIdx +1
    	            DlgApi.SelectImageFrame(self.this, k, v.dirIdx )
    	        else
    	            v.dirIdx = v.dirIdx -1
    	            DlgApi.SelectImageFrame(self.this, k, v.dirIdx)
    	        end
	      	end
	    end
	end
end

function Win_TowerDefense:UpdateTurretDirection(msrv, tk, tv)
   --计算炮塔的方向，根据方向来更换图片
   local dirx = msrv.px + msrv.width/2 - tv.ox
   local diry = msrv.py + msrv.height/2 - tv.oy
   
  	   --根据四个象限进行区域划分，然后根据角度来确定显示图片的序号 		
   local rad = math.atan(math.abs(diry)/math.abs(dirx))
   local thres1 = math.pi/8
   local thres2 = math.pi * 3/8
   if dirx > 0 and diry < 0 then  --第一象限
       if rad < thres1 then
           DlgApi.SelectImageFrame(self.this, tk, 4)
           tv.dirIdx = 4
       elseif rad > thres2 then
           DlgApi.SelectImageFrame(self.this, tk, 8)
           tv.dirIdx = 8
       else
           DlgApi.SelectImageFrame(self.this, tk, 6)
           tv.dirIdx = 6
       end
   elseif dirx < 0 and diry < 0 then --第二象限
       if rad < thres1 then
           DlgApi.SelectImageFrame(self.this, tk, 12)
           tv.dirIdx = 12
       elseif rad > thres2 then
           DlgApi.SelectImageFrame(self.this, tk, 8)
           tv.dirIdx = 8
       else
           DlgApi.SelectImageFrame(self.this, tk, 10)
           tv.dirIdx = 10
       end 
   elseif dirx< 0 and diry >0 then --第三象限
       if rad < thres1 then
           DlgApi.SelectImageFrame(self.this, tk, 12)
           tv.dirIdx = 12
       elseif rad > thres2 then
           DlgApi.SelectImageFrame(self.this, tk, 0)
           tv.dirIdx = 0
       else
           DlgApi.SelectImageFrame(self.this, tk, 14)
           tv.dirIdx = 14
       end        				      
   elseif dirx>0 and diry>0 then --第四象限
       if rad < thres1 then
           DlgApi.SelectImageFrame(self.this, tk, 4)
           tv.dirIdx = 4
       elseif rad > thres2 then
           DlgApi.SelectImageFrame(self.this, tk, 0)
           tv.dirIdx = 0
       else
           DlgApi.SelectImageFrame(self.this, tk, 2)
           tv.dirIdx = 2
       end        				       
   end

   if dirx == 0 then
       if diry > 0 then
           DlgApi.SelectImageFrame(self.this, tk, 0)
           tv.dirIdx = 0
       elseif diry < 0 then
           DlgApi.SelectImageFrame(self.this, tk, 8)
           tv.dirIdx = 8
       end
   end
   
   if diry == 0 then
       if dirx > 0 then
           DlgApi.SelectImageFrame(self.this, tk, 4)
           tv.dirIdx = 4
       elseif dirx <0 then
           DlgApi.SelectImageFrame(self.this, tk, 12)
           tv.dirIdx = 12
       end
   end   
    
end

function Win_TowerDefense:CreateBullet(msrk, vv)
    
   --对于不同类型的炮塔，产生不同类型的子弹
   if vv.weaponType == 1 or vv.weaponType ==2 or vv.weaponType == 3  then  
         				   
	   --local ret = DlgApi.CreateControl(self.this, "bullet", "bullet"..(self.m_bulletIndex+1))
	   local ret = DlgApi.CreateControl(self.this, "hiteffect", "bullet"..(self.m_bulletIndex+1))
	   DlgApi.SetImageFile(self.this, "bullet"..(self.m_bulletIndex+1), "TowerDefense\\effect"..vv.weaponType..".tga", 2)
	   DlgApi.SelectImageFrame(self.this, "bullet"..(self.m_bulletIndex +1), 0) 
	   self.m_bulletIndex = self.m_bulletIndex +1
		
		--子弹也比较大的情况下
	   self:SetItemPos( "bullet"..self.m_bulletIndex, vv.ox - self.m_Map.gridlength +self.m_Map.offsetX, vv.oy - self.m_Map.gridlength + self.m_Map.offsetY)
   elseif vv.weaponType == 4 then
       
	   local ret = DlgApi.CreateControl(self.this, "bulletM","bullet"..(self.m_bulletIndex+1))
	   self.m_bulletIndex = self.m_bulletIndex +1
	   DlgApi.SetImageFile(self.this, "bullet"..self.m_bulletIndex, "TowerDefense\\attack.tga", 8)
	   DlgApi.SelectImageFrame(self.this, "bullet"..self.m_bulletIndex, vv.dirIdx/2)
	   local ox = vv.ox  --计算光效的中心点
	   local oy = vv.oy
	   if vv.dirIdx == 0 or vv.dirIdx == 2 or vv.dirIdx == 14 then
	       oy = oy + self.m_Map.gridlength
	   elseif vv.dirIdx == 6 or vv.dirIdx == 8 or vv.dirIdx == 10 then
	       oy = oy - self.m_Map.gridlength
	   elseif vv.dirIdx == 4 or vv.dirIdx == 2 or vv.dirIdx == 6 then
	       ox = ox + self.m_Map.gridlength
	   elseif vv.dirIdx == 10 or vv.dirIdx == 12 or vv.dirIdx == 14 then
	       ox = ox - self.m_Map.gridlength
	   end
	   self:SetItemPos( "bullet"..self.m_bulletIndex, ox-12 + self.m_Map.offsetX, oy-12 + self.m_Map.offsetY)
   elseif vv.weaponType == 5 then
       
	   local ret = DlgApi.CreateControl(self.this, "bullet", "bullet"..(self.m_bulletIndex+1))        
	   self.m_bulletIndex = self.m_bulletIndex +1								
	   self:SetItemPos( "bullet"..self.m_bulletIndex, vv.ox + self.m_Map.offsetX, vv.oy + self.m_Map.offsetY)            			       
   end

   DlgApi.ShowItem(self.this, "bullet"..self.m_bulletIndex, true)
   --放到前面？
   self.m_Bullets["bullet"..self.m_bulletIndex] = 
   {	weaponType = vv.weaponType, grade = vv.grade, 
   		--大个头的子弹和小个头的子弹， 记录中心点？
   		px = vv.ox, py = vv.oy, 
   		target = msrk, speed = vv.bulletSpeed, 
   		--记录炮塔的位置，为的是群攻的子弹计算子弹到炮塔的距离，记录炮塔的key应该更好
   		wox = vv.ox, woy = vv.oy, 
   		--对可以闪耀的子弹进行控制
   		bulletCounter = 0, bulletTimer = 200,
   		flashTimes = 7, curFlashIdx = 0,
   }            			   
end

function Win_TowerDefense:UpdateMonsters(dwDeltaTime)
    
    for k, v in pairs(self.m_Monsters) do
 		if  v then
			--在走到中心点的时候，获取下一个点		    
 		    local halfgrid = self.m_Map.gridlength/2
 		    --格子中心点与怪物中心点的偏差
 		    local deltax = math.abs(v.gx * self.m_Map.gridlength - halfgrid - v.px - v.width/2 )
 		    local deltay = math.abs(v.gy * self.m_Map.gridlength - halfgrid - v.py - v.height/2 )
 		    
 		    if deltax > self.m_Map.gridlength or deltay > self.m_Map.gridlength then
 		        local msg = Format("\n <%d, %d> \n", deltax, deltay)
 		        LogPrint(msg)
 		       LogPrint("格子中心点与怪物中心点的偏差计算错误")
 		       LogPrint("\n") 
 		    end
 		    
 		    if deltax < halfgrid/4  and deltay < halfgrid/4 then
 		        
	 		    local ret, nextgx, nextgy = GameAI.GetNextPos(v.gx, v.gy, v.route)
--	 		    local msg = Format("\n %d:<%d,%d> -> <%d,%d>\n",v.route, v.gx, v.gy,nextgx or -1, nextgy or -1)
--	 		    LogPrint(msg)
	 		    
				if ret then
				    --correct monster position
    	 		    v.px = v.gx * self.m_Map.gridlength - halfgrid - v.width/2
    	 		    v.py = v.gy * self.m_Map.gridlength - halfgrid - v.height/2
    	 		    				    
    	 		    v.oldgx = v.gx
    	 		    v.oldgy = v.gy
    	 		    v.gx = nextgx
    	 		    v.gy = nextgy
    	 		    --如果有必要的话，更新怪物的方向，也就是更换控件的图片
    	 		    --更换怪物的方向，要记录怪物旧的方向，如果方向不变，不必更换图片
    	 		    local dirx = v.gx - v.oldgx
    	 		    local diry = v.gy - v.oldgy  	 		   
    	 		    
    	 		    if dirx ~= v.dx or diry ~= v.dy then
    	 		    	--update monster direction
    	 		    	v.dx = dirx
    	 		    	v.dy = diry
						--根据方向来更换怪物的图片
						self.UpdateMonsterDirection(self, dirx, diry, k, v)
    	 		    end
				else
				    self.EscapeV( self, k )
				    v = nil
				end 
 		   -- elseif 如果走路不够精确，会出现怪物在原地不动的状态,或者怪物不能正确的按路径运动
 		   -- 怪物的初始状态问题	        
 		    end 		         
 			  
			if v then
			    --更换怪物显示的图片
			    v.frameCounter = v.frameCounter + dwDeltaTime
			    if v.frameCounter > Interval.pigInterval then
			        v.frameCounter = 0
    			    if v.frameIdx < v.framesNum then
    			        DlgApi.SelectImageFrame(self.this, k, v.dirIdx+v.frameIdx)
    			        v.frameIdx = v.frameIdx + 1
    			    else
    			        v.frameIdx = 0
    			    end
			    end
				    
			    if v.bFreeze then 
			        v.freezeCounter = v.freezeCounter + dwDeltaTime
			        if v.freezeCounter > v.freezeTime then
			            v.speed = Monster[v.monsterType].speed
			            v.bFreeze = false
			            v.freezeCounter = 0
			        end
			    end
			--update monster position
     	     	if v.dx ~=0 and v.dy ~=0 then
     	            v.px = v.px + v.speed * v.dx * 0.7071 * dwDeltaTime*0.001
     	            v.py = v.py + v.speed * v.dy * 0.7071 * dwDeltaTime*0.001
     	     	else
     		        v.px = v.px + v.dx * v.speed * dwDeltaTime* 0.001
     		        v.py = v.py + v.dy * v.speed * dwDeltaTime* 0.001
     	     	end	
    			
        		self:SetItemPos( k, v.px + self.m_Map.offsetX, v.py + self.m_Map.offsetY)   --update monster position
        		self:SetItemPos( "monster_hp"..v.id, v.px + self.m_Map.offsetX-2, v.py + self.m_Map.offsetY-4)     --update monster health point position
        		
        		
                for kk, vv in pairs(self.m_Turrets) do
            	    if not vv.bUpgrading then
            	        --中心点与中心点之间的距离
            		   	local dist  =  (v.px + v.width/2 - vv.ox)^2 + (v.py + v.height/2 - vv.oy)^2
            		   	if(dist < vv.range^2 and vv.cool > vv.speed) then
            		   	    vv.cool = 0
            		   	    self.UpdateTurretDirection(self, v, kk, vv) 
							self.CreateBullet(self, k, vv)            
            		   	end
            		end		   
            	end
            	         		        		
    		end  	
        end
  	end 
end

--parameter k
function Win_TowerDefense:EscapeV( monster )
    
    self.m_Player.hp = self.m_Player.hp - 1
    local ratio = self.m_Player.hp/self.m_Player.maxhp
    
    DlgApi.SetProgress(self.this, "progress_hp", ratio )
 
    self.m_curMonsterNum = self.m_curMonsterNum -1
    if self.m_curMonsterNum == 0 and self.m_CurLevel.monsterNum == self.m_curLevelMonsterNum then
        DlgApi.EnableItem(self.this, "Btn_SendNextWave", true)
        self.m_bEnableSendNextWave = true
    end
    DlgApi.DeleteControl(self.this, "monster_hp"..self.m_Monsters[monster].id)
    DlgApi.DeleteControl(self.this, monster)
    self.m_Monsters[monster] = nil 
     
   --玩家的hp减少为0时，先暂停游戏，以后需要进行资源的清除，以及reset        
    if self.m_Player.hp  == 0 then    	
      	self.m_bStart = false
      	DlgApi.ShowItem(self.this, "weaponRange", false)
      	self.Reset(self)
      	return true
    end   
end

function Win_TowerDefense:ProcessMonsterDead( k, v )
    
    DlgApi.CreateControl(self.this, "gfx_test", "gfx_test"..(self.m_gfxIndex +1))
    self.m_gfxIndex = self.m_gfxIndex + 1
    DlgApi.SetImageFile(self.this, "gfx_test"..self.m_gfxIndex, "TowerDefense\\explode.tga", 7)
    DlgApi.SelectImageFrame(self.this, "gfx_test"..self.m_gfxIndex, 0)
    self.m_Gfxs["gfx_test"..self.m_gfxIndex] = { st = 0, idx = 0, framesNum = 7, interval = 120, }
    self:SetItemPos( "gfx_test"..self.m_gfxIndex, v.px + self.m_Map.offsetX, v.py + self.m_Map.offsetY)
    DlgApi.ShowItem(self.this, "gfx_test"..self.m_gfxIndex, true) 
    
    self.IncMoney(self, v.awardMoney)
    self.m_Player.score = self.m_Player.score + v.awardScore
    DlgApi.SetItemText(self.this, "lab_score", "score:"..self.m_Player.score)
    
    DlgApi.DeleteControl(self.this, k)
    DlgApi.DeleteControl(self.this, "monster_hp"..v.id)
    self.m_Monsters[k] = nil
    
    self.m_curMonsterNum = self.m_curMonsterNum - 1
    if self.m_curMonsterNum == 0 and self.m_CurLevel.monsterNum == self.m_curLevelMonsterNum then
        DlgApi.EnableItem(self.this, "Btn_SendNextWave", true)
        self.m_bEnableSendNextWave = true
    end   
end

function Win_TowerDefense:UpdateBullets(dwDeltaTime)
    
  	for k, v in pairs(self.m_Bullets) do
  		if v then
  		    local msr = self.m_Monsters[v.target]
        	local wep = Weapon[v.weaponType][v.grade]
  	   		local dec = 0
			local rnd = math.random()
			--暴击率
			local bCS = false
			if rnd < wep.criticalStrikeRate then
			    bCS = true
			end
    					
  		    if not msr then
  		        DlgApi.DeleteControl(self.this, k)
  		        self.m_Bullets[k] = nil
  		    else 	
  		        v.bulletCounter = v.bulletCounter + dwDeltaTime    
     		        
      		    if v.weaponType == 1 then
      		        --需要考虑子弹的个头，如果很小则需要加上偏移
      				--local dis = ((msr.py + msr.height/2-v.py)^2 + (msr.px + msr.width/2 - v.px)^2)^0.5
      				local dis = ((msr.py -v.py)^2 + (msr.px - v.px)^2)^0.5
      				      				
      				--跟踪型的子弹
      				if(dis < 4) then 
      				    GameAI.Play2DSound("Sfx\\TowerDefense\\Tank_Fire02.wav")
      			   		DlgApi.DeleteControl(self.this, k)
      			   		self.m_Bullets[k] = nil
      			   		--怪物血量减少的数据，以后要从配置文件中读取
      			   		--怪物血量减少的逻辑，以后要根据不同的子弹和怪物本身的属性进行计算（子弹类型）
      			   		--子弹爆炸的效果处理 （平均分配）
      			   		--msr.hp = msr.hp - 1
    					 
      			   		if wep.explodeRange > 0 then
      			   		    for kk,vv in pairs(self.m_Monsters) do
      			   		        --计算中心点之间的距离，需要考虑怪物的大小和子弹的大小
      			   		       	local d = (vv.px + vv.width/2 - v.px)^2 + (vv.py +vv.height/2 -v.py)^2
      			   		        if d < wep.explodeRange^2 then
      			   		            if bCS then
      			   		                dec = (wep.damageA* (1-vv.defenseA) + wep.damageB*(1-vv.defenseB)) *wep.CsFactor * ( 1 - d^0.5/wep.explodeRange )
      			   		            else
      			   		           		dec = (wep.damageA* (1-vv.defenseA) + wep.damageB *(1-vv.defenseB)) * ( 1 - d^0.5/wep.explodeRange )
      			   		            end
    								--中招的效果
    								self.m_Effects["effect"..self.m_effectIndex] = { monster = kk, counter = 0, durTime = 300, frameIdx = 0, framesNum = 1 }
    								DlgApi.CreateControl(self.this, "effect", "effect"..self.m_effectIndex)
    								DlgApi.SetImageFile(self.this, "effect"..self.m_effectIndex, "TowerDefense\\deadeffect.tga", 1)
    								self:SetItemPos( "effect"..self.m_effectIndex, vv.px + self.m_Map.offsetX, vv.py + self.m_Map.offsetY)
    								DlgApi.ShowItem(self.this, "effect"..self.m_effectIndex, true)

    					    		self.m_effectIndex = self.m_effectIndex +1
    					    					
      			   		           	vv.hp = vv.hp - dec
      			   		           	
      			   		           	if vv.hp <= 0 then
      			   		           		self.ProcessMonsterDead(self, kk, vv) 
      			   		           	else
    				  			   		DlgApi.SetProgress(self.this, "monster_hp"..vv.id, vv.hp/vv.maxhp)  			   		           	    				    
      			   		           	end
      			   		        end
      			   		    end
      					else
      					    --子弹不是开花型的
      					    if bCS then
      					    	dec = (wep.damageA*(1-msr.defenseA) + wep.damageB*(1-msr.defenseB)) * wep.CsFactor
      					    else
      					        dec = wep.damageA*(1-msr.defenseA) + wep.damageB*(1-msr.defenseB)
      					    end
      					    msr.hp = msr.hp - dec
      					    if msr.hp <= 0 then
      					        self.ProcessMonsterDead(self, v.target, msr)
      					    else
      					        DlgApi.SetProgress(self.this, "monster_hp"..msr.id, msr.hp/msr.maxhp)
      					    end  					    
      			   		end      			   		    			   		    
      				else
      					--local sina = (msr.py+msr.height/2 - v.py)/dis
      					--local cosa = (msr.px+msr.width/2 - v.px)/dis
      					local sina = (msr.py - v.py)/dis
      					local cosa = (msr.px - v.px)/dis
      					
      			
      					v.px = v.px + v.speed*dwDeltaTime*cosa
      					v.py = v.py + v.speed*dwDeltaTime*sina
      					
      					--子弹两帧在互换
      					if v.bulletCounter > v.bulletTimer then
      					    v.bulletCounter = 0
      					    if v.curFlashIdx == 0 then
	      					    DlgApi.SelectImageFrame(self.this, k, 1)
	      					    v.curFlashIdx = 1
      					    else 
      					        DlgApi.SelectImageFrame(self.this, k, 0)
      					        v.curFlashIdx = 0
      					    end 
      					end
      					
      					self:SetItemPos( k, v.px + self.m_Map.offsetX, v.py + self.m_Map.offsetY)
      				end
      			elseif v.weaponType == 2 then
  					--武器是群攻的
  					--子弹只是记录的炮塔的类型和级别，没有记录位置
  					if v.bulletCounter > v.bulletTimer then
      					DlgApi.DeleteControl(self.this, k)
      					self.m_Bullets[k] = nil
      					for kk, vv in pairs(self.m_Monsters) do
      					   local d = (vv.px +vv.width/2 - v.wox)^2 + (vv.py+ vv.width/2 - v.woy)^2  
      					   if d < wep.range^2 then
      		   		            if bCS then
      		   		                dec = (wep.damageA* (1-vv.defenseA) + wep.damageB*(1-vv.defenseB))*wep.CsFactor 
      		   		            else
      		   		           		dec = wep.damageA* (1-vv.defenseA) + wep.damageB *(1-vv.defenseB)
      		   		            end
      		   		            
      		   		            vv.hp = vv.hp - dec
      		   		            if vv.hp <= 0 then
      		   		                self.ProcessMonsterDead(self, kk, vv)
      		   		            else
      		   		                DlgApi.SetProgress(self.this, "monster_hp"..vv.id, vv.hp/vv.maxhp)
      		   		            end
      					   end
      					end
  					end
  				elseif v.weaponType == 3 then
  				    --减速
 					local dis = ((msr.py -v.py)^2 + (msr.px - v.px)^2)^0.5
      				      				
      				--跟踪型的子弹
      				if(dis < 4) then 
      				    --GameAI.Play2DSound("Sfx\\TowerDefense\\Tank_Fire02.wav")
      			   		DlgApi.DeleteControl(self.this, k)
      			   		self.m_Bullets[k] = nil
      			   		--怪物血量减少的数据，以后要从配置文件中读取
      			   		--怪物血量减少的逻辑，以后要根据不同的子弹和怪物本身的属性进行计算（子弹类型）
      			   		--子弹爆炸的效果处理 （平均分配）
      			   		--msr.hp = msr.hp - 1
    					 
      			   		if wep.explodeRange > 0 then
      			   		    for kk,vv in pairs(self.m_Monsters) do
      			   		       	local d = (vv.px + vv.width/2 - v.px)^2 + (vv.py +vv.height/2 -v.py)^2
      			   		        if d < wep.explodeRange^2 then
      			   		            if bCS then
      			   		                dec = (wep.damageA* (1-vv.defenseA) + wep.damageB*(1-vv.defenseB)) *wep.CsFactor * ( 1 - d^0.5/wep.explodeRange )
      			   		            else
      			   		           		dec = (wep.damageA* (1-vv.defenseA) + wep.damageB *(1-vv.defenseB)) * ( 1 - d^0.5/wep.explodeRange )
      			   		            end      			   		            
		   		           	    
      			   		           	vv.speed = ( 1- wep.reduceSpeed)* vv.speed  
      			   		           	vv.bFreeze = true
      			   		           	vv.freezeTime = wep.durTime    			   		           	    		   		           	    
      			   		           	    								
    								--中招的效果
    								self.m_Effects["effect"..self.m_effectIndex] = { monster = kk, counter = 0, durTime = 100, frameIdx = 0, framesNum = 4 }
    								DlgApi.CreateControl(self.this, "effect", "effect"..self.m_effectIndex)
    								DlgApi.SetImageFile(self.this, "effect"..self.m_effectIndex, "TowerDefense\\beAttack.tga", 4)
    								self:SetItemPos( "effect"..self.m_effectIndex, vv.px + self.m_Map.offsetX, vv.py + self.m_Map.offsetY)
    								DlgApi.ShowItem(self.this, "effect"..self.m_effectIndex, true)

    					    		self.m_effectIndex = self.m_effectIndex +1
    					    					
      			   		           	vv.hp = vv.hp - dec
      			   		           	
      			   		           	if vv.hp <= 0 then
      			   		           		self.ProcessMonsterDead(self, kk, vv) 
      			   		           	else
    				  			   		DlgApi.SetProgress(self.this, "monster_hp"..vv.id, vv.hp/vv.maxhp)  			   		           	    				    
      			   		           	end
      			   		        end
      			   		    end
      			   		end      			   		    			   		    
      				else

      					local sina = (msr.py - v.py)/dis
      					local cosa = (msr.px - v.px)/dis
      					
      			
      					v.px = v.px + v.speed*dwDeltaTime*cosa
      					v.py = v.py + v.speed*dwDeltaTime*sina
      					
      					--子弹两帧在互换
      					if v.bulletCounter > v.bulletTimer then
      					    v.bulletCounter = 0
      					    if v.curFlashIdx == 0 then
	      					    DlgApi.SelectImageFrame(self.this, k, 1)
	      					    v.curFlashIdx = 1
      					    else 
      					        DlgApi.SelectImageFrame(self.this, k, 0)
      					        v.curFlashIdx = 0
      					    end 
      					end
      					
      					self:SetItemPos( k, v.px + self.m_Map.offsetX, v.py + self.m_Map.offsetY)
      				end  				    	
      		    elseif v.weaponType == 4 then
      		       	--v.bulletCounter = v.bulletCounter + dwDeltaTime
      		       	if v.bulletCounter > v.bulletTimer then
      		           if v.curFlashIdx == v.flashTimes then
          		          	DlgApi.ShowItem(self.this, k, false)
          		          	DlgApi.DeleteControl(self.this, k)
          		          	self.m_Bullets[k] = nil 
      	   		            if bCS then
      	   		                dec = (wep.damageA* (1-msr.defenseA) + wep.damageB*(1-msr.defenseB))*wep.CsFactor 
      	   		            else
      	   		           		dec = wep.damageA* (1-msr.defenseA) + wep.damageB *(1-msr.defenseB)
      	   		            end
      	   		            --击中光效
      	   		            --DlgApi.CreateControl(self.this, "hiteffect", "effect"..self.m_effectIndex)
      	   		            --DlgApi.SetImageFile(self.this, "effect"..self.m_effectIndex, "TowerDefense\\effect1.tga", 2)
      	   		            --DlgApi.SelectImageFrame(self.this, "effect"..self.m_effectIndex, 0)
      	   		            --self:SetItemPos( "effect"..self.m_effectIndex, msr.px, msr.py)
 							--DlgApi.ShowItem(self.this, "effect"..self.m_effectIndex, true)
 							--self.m_Effects["effect"..self.m_effectIndex] = { monster = msr, counter = 0, durTime = 500, frameIdx = 0, framesNum = 2 }

      	   		            --self.m_effectIndex = self.m_effectIndex +1
      	   		            
--      	   		            self.m_TestEffects["testeffect"..self.m_testIndex] = { counter = 0, }
--							DlgApi.CreateControl(self.this, "hiteffect", "testeffect"..self.m_testIndex)
--							self:SetItemPos( "testeffect"..self.m_testIndex, msr.px, msr.py)
--							DlgApi.ShowItem(self.this, "testeffect"..self.m_testIndex, true)
--							
--							self.m_testIndex = self.m_testIndex +1     								

      					   	msr.hp = msr.hp - dec
      					    if msr.hp <= 0 then
      					        self.ProcessMonsterDead(self, v.target, msr)
      					    else
      					        DlgApi.SetProgress(self.this, "monster_hp"..msr.id, msr.hp/msr.maxhp)
      					    end    				    
      		           else
      		               	v.curFlashIdx = v.curFlashIdx +1
  						    if v.curFlashIdx % 2 == 0 then
  						        DlgApi.ShowItem(self.this, k, false)
  						    else
  						        DlgApi.ShowItem(self.this, k, true)
  						    end
      		           end    		               
      		    	end
      		    elseif v.weaponType == 5 then
      				local dis = ((msr.py + msr.height/2-v.py)^2 + (msr.px + msr.width/2 - v.px)^2)^0.5
      				      				
      				--跟踪型的子弹
      				if(dis < 4) then 
      				    GameAI.Play2DSound("Sfx\\TowerDefense\\Tank_Fire02.wav")
      			   		DlgApi.DeleteControl(self.this, k)
      			   		self.m_Bullets[k] = nil
      			   		--怪物血量减少的数据，以后要从配置文件中读取
      			   		--怪物血量减少的逻辑，以后要根据不同的子弹和怪物本身的属性进行计算（子弹类型）
      			   		--子弹爆炸的效果处理 （平均分配）
      			   		--msr.hp = msr.hp - 1
    					 
      			   		if wep.explodeRange > 0 then
      			   		    for kk,vv in pairs(self.m_Monsters) do
      			   		       	local d = (vv.px + vv.width/2 - v.px)^2 + (vv.py +vv.height/2 -v.py)^2
      			   		        if d < wep.explodeRange^2 then
      			   		            if bCS then
      			   		                dec = (wep.damageA* (1-vv.defenseA) + wep.damageB*(1-vv.defenseB)) *wep.CsFactor * ( 1 - d^0.5/wep.explodeRange )
      			   		            else
      			   		           		dec = (wep.damageA* (1-vv.defenseA) + wep.damageB *(1-vv.defenseB)) * ( 1 - d^0.5/wep.explodeRange )
      			   		            end
    											
      			   		           	vv.hp = vv.hp - dec
      			   		           	
      			   		           	if vv.hp <= 0 then
      			   		           		self.ProcessMonsterDead(self, kk, vv) 
      			   		           	else
    				  			   		DlgApi.SetProgress(self.this, "monster_hp"..vv.id, vv.hp/vv.maxhp)  			   		           	    				    
      			   		           	end
      			   		        end
      			   		    end
      					else
      					    --子弹不是开花型的
      					    if bCS then
      					    	dec = (wep.damageA*(1-msr.defenseA) + wep.damageB*(1-msr.defenseB)) * wep.CsFactor
      					    else
      					        dec = wep.damageA*(1-msr.defenseA) + wep.damageB*(1-msr.defenseB)
      					    end
      					    msr.hp = msr.hp - dec
      					    if msr.hp <= 0 then
      					        self.ProcessMonsterDead(self, v.target, msr)
      					    else
      					        DlgApi.SetProgress(self.this, "monster_hp"..msr.id, msr.hp/msr.maxhp)
      					    end  					    
      			   		end      			   		    			   		    
      				else
      					local sina = (msr.py+msr.height/2 - v.py)/dis
      					local cosa = (msr.px+msr.width/2 - v.px)/dis      					
      			
      					v.px = v.px + v.speed*dwDeltaTime*cosa
      					v.py = v.py + v.speed*dwDeltaTime*sina

      					self:SetItemPos( k, v.px + self.m_Map.offsetX, v.py+ self.m_Map.offsetY)
      				end
      		              		        	  					
      			end
      			
      		end
  		
  		end
  	end 

    
end
 
 
function Win_TowerDefense:UpdateEffects(dwDeltaTime)
	for k,v in pairs (self.m_Effects) do
	    if v then
	        local msr = self.m_Monsters[v.monster]
	        if msr then
	            self:SetItemPos( k, msr.px + self.m_Map.offsetX, msr.py + self.m_Map.offsetY)
	        else
                DlgApi.ShowItem(self.this, k, false)
                DlgApi.DeleteControl(self.this, k)
                self.m_Effects[k] = nil
	        end	            
	        v.counter = v.counter + dwDeltaTime
	        --if v.counter > Interval.effectInterval then
	        if v.counter > v.durTime then
	            v.counter  = 0
	            v.frameIdx = v.frameIdx + 1
	            if v.frameIdx == v.framesNum then
	                DlgApi.ShowItem(self.this, k, false)
	                DlgApi.DeleteControl(self.this, k)
	                self.m_Effects[k] = nil
	            else
		            DlgApi.SelectImageFrame(self.this, k, v.frameIdx)
	            end
	        end
	    end
	end
	
	for k, v in pairs(self.m_TestEffects) do
	    if v then
	        v.counter = v.counter + dwDeltaTime
	        if v.counter > Interval.testEffectInterval then
	            DlgApi.DeleteControl(self.this, k)
	            self.m_TestEffects[k] = nil
	        end
	    end
	end
end

function Win_TowerDefense:Reset()
				
	for k, v in pairs(self.m_Monsters) do
	    if v then
	        DlgApi.DeleteControl(self.this, k)
	        DlgApi.DeleteControl(self.this, "monster_hp"..v.id)
	        self.m_Monsters[k] = nil
	    end
	end
	
	for k, v in pairs(self.m_Turrets) do
	    if v then
	        DlgApi.DeleteControl(self.this, k)
	        self.m_Turrets[k] = nil
	    end
	end
	
	for k, v in pairs(self.m_Bullets) do
	    if v then
	        DlgApi.DeleteControl(self.this, k)
	        self.m_Turrets[k] = nil
	    end
	end
	
	for k, v in pairs(self.m_Gfxs) do
	    if v then
	        DlgApi.DeleteControl(self.this, k)
	        self.m_Gfxs[k] = nil
	    end
	end
	
	for k,v in pairs(self.m_Prgs) do 
	    if v then
	        DlgApi.DeleteControl(self.this, k)
	        self.m_Prgs[k] = nil
	    end
	end
	
	for k, v in pairs(self.m_Effects) do
	    if v then
	        DlgApi.DeleteControl(self.this,k)
	        self.m_Effects[k]= nil
	    end
	end
	
	for k, v in pairs(self.m_TestEffects) do 
	    if v then 
	        DlgApi.DeleteControl(self.this,k)
	        self.m_TestEffects[k] = nil
	    end
	end
	
    self.m_Monsters = {}
    self.m_Turrets = {}
    self.m_Bullets = {}
    self.m_Gfxs = {}
    self.m_Map2Turrets = {}
    self.m_Map2MonsterPos = {}
    self.m_Player = {}
    self.m_Mission = {}
    self.m_CurLevel = {}
    self.m_Map = {}
    self.m_Prgs = {}
    self.m_Effects = {}
    self.m_TestEffects = {}
    self.m_PlaceGrid = {}
    self.m_levelIndex = 1
    self.m_Timer = 0
    self.m_levelTimer = 0
    self.m_curLevelMonsterNum = 0
    self.m_curMonsterNum = 0
    self.m_bStart = false
    self.m_bChoseTurretBuy = false
    self.m_bChoseTurretSell = false
    self.m_bSendNextLevelMonster = true
    self.m_bEnableSendNextWave = false
    self.m_bLButtonDown = false
    self.m_bPause = false
    self.m_bCanPlace = false
    self.m_missionIndex = 1
    self.m_turretIndex =0
    self.m_monsterIndex =0
    self.m_bulletIndex =0
    self.m_gfxIndex = 0
    self.m_prgIndex = 1
    self.m_effectIndex = 1
    self.m_testIndex = 1
    self.m_ChosedTurret = 0
    self.m_ChosedMonster = 0
    
	self.m_Player = CopyTable(Player)
	self.m_Player["maxhp"] = Player.hp
	
	self.m_Mission = CopyTable(Mission[self.m_missionIndex])
	self.m_CurLevel = self.m_Mission[self.m_levelIndex]
	self.m_Map = CopyTable(Map)
	
	for i=1, self.m_Map.width do 
	    self.m_Map2Turrets[i] = {}
	    self.m_Map2MonsterPos[i] = {}
	    for j=1, self.m_Map.height do
	        self.m_Map2Turrets[i][j] = false
	        self.m_Map2MonsterPos[i][j] = false
	    end
	end
	
	for i=1, self.m_Map.width do
	    self.m_Map2Turrets[i][1] = true
	    self.m_Map2Turrets[i][self.m_Map.height] = true
	end
	
	for j=1, self.m_Map.height do
	    self.m_Map2Turrets[1][j] = true
	    self.m_Map2Turrets[self.m_Map.width][j] = true
	end
	
	GameAI.ClearTDMap()
end